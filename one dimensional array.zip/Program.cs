﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace one_dimensional_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            int[] x;
            x = new int[5];
            Console.Write("Enter Elements:\n");
            for (i = 0; i < 5; i++)
            {
                Console.Write("\t Element[" + i + "]:");
                x[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.Write("\n \n Element are:\n");
            for (i = 0; i < 5; i++)
            {
                Console.WriteLine("\t Element[" + i + "]:" + x[i]);
            }
            Console.Read();
        }
    }
}



/*output:
 * Enter Elements:
 * Element[0]:10
 * Element[1]:20
 * Element[2]:30
 * Element[3]:40
 * Element[4]:50
 * 
 * Elements are:
 * Element[0]:10
 * Element[1]:20
 * Element[2]:30
 * Element[3]:40
 * Element[4]:50
*/